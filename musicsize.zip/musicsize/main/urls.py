from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('index.html', views.index, name='index'),
    path('register.html', views.regist, name='regist'),
    path('login.html', views.login, name='login'),
]
