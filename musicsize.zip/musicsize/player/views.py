from django.shortcuts import render, redirect
from django.shortcuts import get_object_or_404

# Create your views here.
from .models import Song
from .forms import SongForm
from .forms import SearchForm
from django.http import JsonResponse
from django.views import View


def player(request):
    form = SearchForm()  # Создание экземпляра формы
    songs = Song.objects.all()

    if request.method == 'GET':
        form = SearchForm(request.GET)  # Привязка данных из запроса к форме, если запрос GET

    if form.is_valid():
        query = form.cleaned_data.get('query')
        songs = songs.filter(title__icontains=query) | songs.filter(artist__icontains=query)

    return render(request, 'main/index.html', {'songs': songs, 'form': form} )

def upload_song(request):
    if request.method == 'POST':
        form = SongForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('')
    else:
        form = SongForm()
    return render(request, 'player/upload_song.html', {'form': form})

def search(request, track_id=None):
    if track_id is not None:
        # Получаем трек по уникальному идентификатору из URL
        track = get_object_or_404(Song, id=track_id)
        # Формируем JSON ответ с информацией о треке
        result = {
            'url': track.url,
            'title': track.title,
            'artist': track.artist
        }
        return JsonResponse(result)
    else:
        query = request.GET.get('q', '')
        if query:
            results = Song.objects.filter(title__icontains=query) | Song.objects.filter(artist__icontains=query)
            results = list(results.values('url', 'title', 'artist'))
        else:
            results = []
        return JsonResponse(results, safe=False)
