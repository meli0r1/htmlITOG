from django.db import models

# Create your models here.

class Song(models.Model):
    title = models.CharField(max_length=100)
    artist = models.CharField(max_length=100)
    genre = models.CharField(max_length=100)
    url = models.IntegerField()  # Добавляем поле для URL трека
    file = models.FileField(upload_to='songs/')

    def __str__(self):
        return f'{self.artist} - {self.title} - {self.genre} - {self.url} '
