from django.urls import path
from . import views
from .views import search

urlpatterns = [
    path('index.html', views.player, name='player'),
    path('', views.player, name='player'),
    path('upload_song.html', views.upload_song, name='upload_song'),
]